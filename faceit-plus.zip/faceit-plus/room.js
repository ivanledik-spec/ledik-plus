window.FXR = (() => {
  let notes = {}, last = null, lastCtx = null;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = v => { const n = parseFloat(String(v ?? '').replace(',', '.')); return isNaN(n) ? null : n; };
  const avg = a => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
  const fmt = (n, d = 2) => (n == null ? '—' : n.toFixed(d));
  const col = (ms, k) => ms.map(s => num(s[k])).filter(x => x != null);
  const roomId = () => (location.pathname.match(/\/room\/(1-[0-9a-f-]{36})/i) || [])[1] || null;

  function calc(p, map) {
    const ms = p.matches.map(m => m.stats || {}), kd = col(ms, 'K/D Ratio');
    const adr = ms.map(s => num(s['ADR'] ?? s['Average Damage per Round'])).filter(x => x != null);
    const onMap = map ? ms.filter(s => s['Map'] === map) : [];
    return {
      kd: avg(kd), adr: avg(adr), hs: avg(col(ms, 'Headshots %')),
      form: kd.length >= 10 ? avg(col(ms.slice(0, 10), 'K/D Ratio')) - avg(kd) : null,
      wr: onMap.length ? Math.round((100 * onMap.filter(s => s['Result'] === '1').length) / onMap.length) : null, nMap: onMap.length
    };
  }

  function meetCell(p) {
    const d = last;
    if (!d.meets) return '<td>—</td>';
    if (p.id === d.meId) return '<td>ты</td>';
    const list = d.meets[p.id];
    if (!list || !list.length) return '<td>—</td>';
    const g = same => {
      const a = list.filter(x => x.same === same);
      if (!a.length) return '';
      return `${same ? 'с' : 'пр'} ${a.length} (${a.filter(x => x.win === true).length}–${a.filter(x => x.win === false).length})`;
    };
    const tip = list.slice(0, 8).map(x => `${new Date(x.t > 1e12 ? x.t : x.t * 1000).toLocaleDateString('ru-RU')} · ${x.same ? 'вместе' : 'против'} · ${x.win == null ? '?' : x.win ? 'победа' : 'поражение'}`).join('\n');
    return `<td title="${esc(tip)}" style="color:#fbbf24">${[g(true), g(false)].filter(Boolean).join(' · ')}</td>`;
  }

  function team(t, ps, map, eA, eB) {
    let pw = num(t.winProb);
    const fromApi = pw != null;
    if (fromApi && pw > 1) pw /= 100;
    if (!fromApi && eA != null && eB != null) pw = 1 / (1 + 10 ** ((eB - eA) / 400));
    const info = pw == null ? '' : ` · шанс ${fromApi ? '' : '≈ '}${Math.round(pw * 100)}%` +
      (t.calcElo === false ? ' · ELO не считается' : ` · ≈ +${Math.round(50 * (1 - pw))} / −${Math.round(50 * pw)}`);
    const rows = ps.map(p => {
      const c = calc(p, map), note = notes[p.nick.toLowerCase()];
      return `<tr><td><span data-note="${esc(p.nick)}" title="${esc(note || 'Добавить заметку')}">${note ? '📝 ' : ''}${esc(p.nick)}</span></td><td>${esc(p.level ?? '—')}</td><td>${esc(p.elo ?? '—')}</td><td>${fmt(c.kd)}</td><td>${fmt(c.adr, 0)}</td><td>${fmt(c.hs, 0)}</td><td>${c.wr == null ? '—' : c.wr + '% (' + c.nMap + ')'}</td><td class="${c.form >= 0 ? 'pos' : 'neg'}">${c.form == null ? '—' : (c.form >= 0 ? '↑' : '↓') + Math.abs(c.form).toFixed(2)}</td>${meetCell(p)}</tr>`;
    }).join('');
    return `<tr class="tm"><td colspan="9">${esc(t.name || 'Команда')} · ср. ELO ${eA == null ? '—' : Math.round(eA)}${info}</td></tr>${rows}`;
  }

  async function draw(ctx) {
    notes = (await chrome.storage.local.get('fxpNotes')).fxpNotes || {};
    const d = last, e = d.teams.map((_, i) => avg(d.players.filter(p => p.team === i && p.elo != null).map(p => p.elo)));
    const body = d.teams.map((t, i) => team(t, d.players.filter(p => p.team === i), d.map, e[i], e[1 - i])).join('');
    ctx.box.innerHTML = ctx.head('Матчрум' + (d.map ? ' · ' + d.map.replace('de_', '') : '')) +
      `<div class="body"><table><tr><th>Игрок</th><th>Ур</th><th>ELO</th><th>K/D</th><th>ADR</th><th>HS%</th><th>WR карты</th><th>Форма</th><th>Встречи</th></tr>${body}</table>
<div class="t mu">K/D, ADR, HS — последние 30 матчей. Форма — K/D последних 10 минус средний за 30. Шанс — данные FACEIT, а если API их не отдал, оценка по ELO (знак ≈). ±ELO — моя оценка (K≈50). Встречи — по твоим последним ~300 матчам (с — в одной команде, пр — против; в скобках победы–поражения). Клик по нику — заметка.</div></div>`;
  }

  async function show(ctx, force) {
    lastCtx = ctx;
    ctx.box.innerHTML = ctx.head('Матчрум') + '<p class="m">Загружаю 10 игроков, до 20 секунд…</p>';
    let r;
    try { r = await chrome.runtime.sendMessage({ type: 'room', id: roomId(), key: ctx.S.apiKey, me: ctx.S.nick, force }); } catch { return; }
    if (!ctx.alive()) return;
    if (!r || !r.ok) { ctx.box.innerHTML = ctx.head('Матчрум') + `<p class="m">${esc(r ? r.error : 'Нет ответа')}</p>`; return; }
    last = r.data; draw(ctx);
  }

  async function note(nick, ctx) {
    const k = nick.toLowerCase(), t = prompt('Заметка про ' + nick + ' (пусто — удалить):', notes[k] || '');
    if (t === null) return;
    if (t.trim()) notes[k] = t.trim(); else delete notes[k];
    await chrome.storage.local.set({ fxpNotes: notes });
    if (last) draw(ctx || lastCtx);
  }

  return { roomId, show, note };
})();
