(() => {
  'use strict';
  const DEF = { apiKey: '', nick: '', wpOn: true, wallpaper: '', dim: 45, blur: 0, accent: '#ff5500', panelOn: true, custom: '', roomOn: true, neon: false, font: '' };
  let S = { ...DEF }, host = null, root = null, collapsed = false, token = 0, lastNick = null, lastLoad = 0;

  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = v => { const n = parseFloat(String(v ?? '').replace(',', '.')); return isNaN(n) ? null : n; };
  const fmt = (n, d = 2) => (n == null ? '—' : n.toFixed(d));
  const avg = a => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
  const pageNick = () => { const m = location.pathname.match(/\/players\/([^/?#]+)/); return m ? decodeURIComponent(m[1]) : null; };

  const fontCss = () => {
    const f = String(S.font || '').replace(/[^\p{L}\p{N}\s-]/gu, '').trim();
    return f ? `html body :where(div,span,p,a,button,input,textarea,h1,h2,h3,h4,h5,h6,li,td,th,label){font-family:"${f}",sans-serif!important}` : '';
  };
  /* ---------- обои ---------- */
  function applyStyle() {
    let st = document.getElementById('fxp-style');
    if (!st) { st = document.createElement('style'); st.id = 'fxp-style'; document.documentElement.append(st); }
    let wp = document.getElementById('fxp-wp');
    if (S.wpOn && S.wallpaper) {
      if (!wp) { wp = document.createElement('div'); wp.id = 'fxp-wp'; document.documentElement.append(wp); }
      const d = S.dim / 100, url = S.wallpaper.replace(/"/g, '%22');
      wp.style.cssText = `position:fixed;inset:-20px;z-index:-1;pointer-events:none;background:linear-gradient(rgba(0,0,0,${d}),rgba(0,0,0,${d})),url("${url}") center/cover no-repeat;filter:blur(${S.blur}px)`;
      st.textContent = 'html,body,#root,#__next,#app{background:transparent!important}' + fontCss() + S.custom;
    } else { if (wp) wp.remove(); st.textContent = fontCss() + S.custom; }
  }

  /* ---------- панель ---------- */
  const CSS = `.box{--a:#ff5500;width:300px;max-height:80vh;overflow:auto;font:13px/1.4 system-ui,sans-serif;color:#eee;background:rgba(18,18,20,.92);border:1px solid #2c2c30;border-left:3px solid var(--a);border-radius:8px;backdrop-filter:blur(8px)}
.h{display:flex;justify-content:space-between;align-items:center;padding:8px 10px}.h b{font-size:14px}
button{background:none;border:0;color:#aaa;cursor:pointer;font-size:14px;padding:2px 6px}button:hover{color:#fff}
.body{padding:0 10px 10px}.c .body{display:none}.m{padding:0 10px 10px;margin:0;color:#aaa}
.top{display:flex;gap:10px;align-items:baseline;margin-bottom:8px}.elo{font-size:26px;font-weight:700;color:var(--a)}.mu{color:#8b8b94;font-size:11px}
.g{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}.s{background:#232327;border-radius:6px;padding:6px 8px}.s span{display:block;font-size:11px;color:#8b8b94}.s b{font-size:15px}
.sp{display:flex;align-items:flex-end;gap:2px;height:44px;margin:4px 0 8px}.sp i{flex:1;border-radius:1px}.w{background:#4ade80}.l{background:#f87171}
table{width:100%;border-collapse:collapse;font-size:12px}td,th{padding:2px 0;text-align:right}td:first-child,th:first-child{text-align:left}th{color:#8b8b94;font-weight:400}
.pos{color:#4ade80}.neg{color:#f87171}.t{margin:8px 0 2px}.tm td{padding-top:8px;color:#ddd;text-align:left}[data-note]{cursor:pointer}`;

  function ensurePanel() {
    if (!S.panelOn) { if (host) host.remove(); host = null; return false; }
    if (host && host.isConnected) return true;
    host = document.createElement('div'); host.id = 'fxp-host';
    host.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647';
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${CSS}</style><div class="box"></div>`;
    root.addEventListener('click', e => {
      const n = e.target.closest('[data-note]'); if (n) { FXR.note(n.dataset.note, mkCtx()); return; }
      const a = e.target.closest('[data-act]'); if (!a) return;
      if (a.dataset.act === 'ref') refresh(true);
      if (a.dataset.act === 'col') { collapsed = !collapsed; root.querySelector('.box').classList.toggle('c', collapsed); }
      if (a.dataset.act === 'opts') chrome.runtime.sendMessage({ type: 'opts' });
    });
    document.documentElement.append(host);
    return true;
  }

  const head = t => `<div class="h"><b>${esc(t)}</b><span><button data-act="ref" title="Обновить">↻</button><button data-act="col" title="Свернуть">–</button></span></div>`;

  function view(d, delta) {
    const g = (d.player.games && d.player.games.cs2) || {};
    const L = (d.stats && d.stats.lifetime) || {};
    const ms = d.matches.map(m => m.stats || {});
    const kd = ms.map(s => num(s['K/D Ratio'])).filter(x => x != null);
    const hs = ms.map(s => num(s['Headshots %'])).filter(x => x != null);
    const adr = ms.map(s => num(s['ADR'] ?? s['Average Damage per Round'])).filter(x => x != null);
    const wins = ms.filter(s => s['Result'] === '1').length;
    const bars = [...ms].reverse().map(s => {
      const k = num(s['K/D Ratio']) || 0, h = Math.max(6, Math.min(100, (k / 2) * 100));
      return `<i class="${s['Result'] === '1' ? 'w' : 'l'}" style="height:${h}%" title="${esc(s['Map'])} ${esc(s['Score'])} · K/D ${k}"></i>`;
    }).join('');
    const maps = ((d.stats && d.stats.segments) || []).filter(x => x.type === 'Map')
      .sort((a, b) => (num(b.stats['Matches']) || 0) - (num(a.stats['Matches']) || 0)).slice(0, 7)
      .map(x => `<tr><td>${esc(String(x.label).replace('de_', ''))}</td><td>${esc(x.stats['Matches'])}</td><td>${esc(x.stats['Win Rate %'])}%</td><td>${esc(x.stats['Average K/D Ratio'])}</td></tr>`).join('');
    const sd = delta == null ? '' : `<span class="${delta >= 0 ? 'pos' : 'neg'}" title="Изменение ELO за сессию">${delta >= 0 ? '+' : ''}${delta}</span>`;
    const st = (l, v) => `<div class="s"><span>${l}</span><b>${v}</b></div>`;
    return `<div class="body"><div class="top"><span class="elo">${esc(g.faceit_elo ?? '—')}</span><span>ур. ${esc(g.skill_level ?? '—')}</span>${sd}<span class="mu">${esc(g.region || '')}</span></div>
<div class="g">${st('Матчи', esc(L['Matches'] ?? '—'))}${st('Винрейт', esc(L['Win Rate %'] ?? '—') + '%')}${st('K/D', esc(L['Average K/D Ratio'] ?? '—'))}${st('HS %', esc(L['Average Headshots %'] ?? '—'))}${st('Серия', esc(L['Current Win Streak'] ?? '—'))}${st('Рекорд серии', esc(L['Longest Win Streak'] ?? '—'))}</div>
<div class="t mu">Последние ${ms.length}: ${wins} поб. · K/D ${fmt(avg(kd))} · HS ${fmt(avg(hs), 0)}% · ADR ${fmt(avg(adr), 0)}</div><div class="sp">${bars}</div>
${maps ? `<table><tr><th>Карта</th><th>Матчи</th><th>WR</th><th>K/D</th></tr>${maps}</table>` : ''}</div>`;
  }

  async function sessionDelta(elo) {
    const { fxpBase } = await chrome.storage.local.get('fxpBase'), now = Date.now();
    if (!fxpBase || fxpBase.nick !== S.nick || now - fxpBase.ts > 8 * 3600e3) {
      await chrome.storage.local.set({ fxpBase: { nick: S.nick, elo, ts: now } }); return 0;
    }
    await chrome.storage.local.set({ fxpBase: { ...fxpBase, ts: now } });
    return elo - fxpBase.elo;
  }

  function mkCtx() { const my = token; return { box: root.querySelector('.box'), S, head, alive: () => my === token }; }

  async function refresh(force) {
    if (!ensurePanel()) return;
    const rid = S.roomOn ? FXR.roomId() : null, nick = pageNick() || S.nick, box = root.querySelector('.box');
    box.style.setProperty('--a', S.accent); box.classList.toggle('c', collapsed);
    box.style.boxShadow = S.neon ? `0 0 14px ${S.accent}, 0 0 2px ${S.accent}` : '';
    box.style.width = rid ? '640px' : '300px';
    lastNick = rid || nick; lastLoad = Date.now();
    if (rid && S.apiKey) { ++token; FXR.show(mkCtx(), force); return; }
    if (!S.apiKey || !nick) {
      box.innerHTML = head('FACEIT Plus') + `<p class="m">${!S.apiKey ? 'Добавь API-ключ' : 'Укажи свой ник'} в настройках.</p><p class="m"><button data-act="opts">Открыть настройки</button></p>`;
      return;
    }
    const my = ++token; lastNick = nick; lastLoad = Date.now();
    box.innerHTML = head(nick) + '<p class="m">Загрузка…</p>';
    let r;
    try { r = await chrome.runtime.sendMessage({ type: 'stats', nick, key: S.apiKey, force }); }
    catch { return; /* расширение перезагружено — обнови вкладку */ }
    if (my !== token) return;
    if (!r || !r.ok) { box.innerHTML = head(nick) + `<p class="m">${esc(r ? r.error : 'Нет ответа')}</p>`; return; }
    const elo = num(r.data.player.games && r.data.player.games.cs2 && r.data.player.games.cs2.faceit_elo);
    const mine = S.nick && nick.toLowerCase() === S.nick.toLowerCase();
    const delta = mine && elo != null ? await sessionDelta(elo) : null;
    box.innerHTML = head(r.data.player.nickname || nick) + view(r.data, delta);
  }

  /* ---------- запуск ---------- */
  async function loadSettings() { S = { ...DEF, ...(await chrome.storage.local.get(Object.keys(DEF))) }; applyStyle(); }
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && Object.keys(ch).some(k => k in DEF)) loadSettings().then(() => refresh(true));
  });
  loadSettings().then(() => refresh(false));
  setInterval(() => {   // сайт — SPA: следим за сменой страницы и обновляем раз в 5 минут
    const rid = S.roomOn && FXR.roomId(), n = rid || pageNick() || S.nick;
    if (n !== lastNick || (!rid && Date.now() - lastLoad > 3e5)) refresh(false);
    if (!document.getElementById('fxp-wp') && S.wpOn && S.wallpaper) applyStyle();
  }, 1500);
})();
