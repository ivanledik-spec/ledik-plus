const $ = id => document.getElementById(id);
const DEF = { apiKey: '', nick: '', wpOn: true, wallpaper: '', dim: 45, blur: 0, accent: '#ff5500', panelOn: true, custom: '', roomOn: true, neon: false, font: '', soundId: 'chime', soundVol: 70, soundCustom: '', acceptWords: 'accept, принять' };
let wallpaper = '', soundCustom = '';

function preview() {
  $('dimV').textContent = $('dim').value; $('blurV').textContent = $('blur').value;
  const d = $('dim').value / 100, u = wallpaper.replace(/"/g, '%22');
  $('pv').firstElementChild.style.cssText = wallpaper
    ? `background-image:linear-gradient(rgba(0,0,0,${d}),rgba(0,0,0,${d})),url("${u}");filter:blur(${$('blur').value}px);transform:scale(1.1)` : '';
}

(async () => {
  $('soundId').innerHTML = '<option value="off">Выключен</option>' + Object.entries(FXS.NAMES).map(([k, v]) => `<option value="${k}">${v}</option>`).join('') + '<option value="custom">Свой файл</option>';
  const s = { ...DEF, ...(await chrome.storage.local.get(Object.keys(DEF))) };
  for (const k of ['apiKey', 'nick', 'dim', 'blur', 'accent', 'custom', 'font', 'soundId', 'soundVol', 'acceptWords']) $(k).value = s[k];
  $('wpOn').checked = s.wpOn; $('panelOn').checked = s.panelOn; $('roomOn').checked = s.roomOn; $('neon').checked = s.neon;
  soundCustom = s.soundCustom; $('soundVV').textContent = s.soundVol; wallpaper = s.wallpaper; $('wallpaper').value = wallpaper.startsWith('data:') ? '(загруженный файл)' : wallpaper;
  preview();
})();

$('wallpaper').oninput = e => { wallpaper = e.target.value.trim(); preview(); };
$('dim').oninput = $('blur').oninput = preview;
$('pick').onclick = () => $('file').click();
$('clear').onclick = () => { wallpaper = ''; $('wallpaper').value = ''; preview(); };
$('file').onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  if (f.type === 'image/gif') {
    if (f.size > 2e6) { $('st').textContent = 'GIF больше 2 МБ, уменьши его'; return; }
    wallpaper = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(f); });
    $('wallpaper').value = '(загруженный файл: ' + f.name + ')'; preview(); return;
  }
  const img = await createImageBitmap(f), k = Math.min(1, 2560 / img.width), c = document.createElement('canvas');
  c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
  c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
  wallpaper = c.toDataURL('image/jpeg', 0.88); $('wallpaper').value = '(загруженный файл: ' + f.name + ')'; preview();
};

$('save').onclick = async () => {
  await chrome.storage.local.set({
    apiKey: $('apiKey').value.trim(), nick: $('nick').value.trim(), wpOn: $('wpOn').checked, wallpaper,
    dim: +$('dim').value, blur: +$('blur').value, accent: $('accent').value, panelOn: $('panelOn').checked, custom: $('custom').value,
    roomOn: $('roomOn').checked, neon: $('neon').checked, font: $('font').value.trim(),
    soundId: $('soundId').value, soundVol: +$('soundVol').value, soundCustom, acceptWords: $('acceptWords').value
  });
  $('st').textContent = 'Сохранено'; setTimeout(() => ($('st').textContent = ''), 2000);
};

$('test').onclick = async () => {
  const key = $('apiKey').value.trim(), nick = $('nick').value.trim();
  if (!key || !nick) { $('res').textContent = 'Введи ключ и ник.'; return; }
  $('res').textContent = 'Проверяю…'; $('rawBox').hidden = true;
  const r = await chrome.runtime.sendMessage({ type: 'stats', nick, key, force: true });
  if (!r.ok) { $('res').textContent = 'Ошибка: ' + r.error; return; }
  const g = (r.data.player.games || {}).cs2 || {};
  $('res').textContent = `Найден: ${r.data.player.nickname}, ELO ${g.faceit_elo ?? '—'}, уровень ${g.skill_level ?? '—'}, матчей в истории: ${r.data.matches.length}`;
  $('raw').textContent = JSON.stringify({ cs2: g, lifetime: r.data.stats.lifetime, firstMapSegment: (r.data.stats.segments || [])[0], lastMatch: (r.data.matches[0] || {}).stats }, null, 1);
  $('rawBox').hidden = false;
};

$('soundVol').oninput = () => ($('soundVV').textContent = $('soundVol').value);
$('soundTest').onclick = () => FXS.play($('soundId').value, $('soundVol').value / 100, soundCustom);
$('soundPick').onclick = () => $('soundFile').click();
$('soundFile').onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  if (f.size > 1e6) { $('st').textContent = 'Звук больше 1 МБ'; return; }
  soundCustom = await new Promise(r => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(f); });
  $('soundId').value = 'custom'; $('soundName').textContent = f.name;
};
