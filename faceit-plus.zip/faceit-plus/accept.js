(() => {
  // Только слушает страницу и играет звук. Ничего не нажимает.
  let cfg = { soundId: 'chime', soundVol: 70, soundCustom: '', acceptWords: 'accept, принять' };
  let shown = false, timer = null;
  const t0 = performance.now();

  const load = async () => { cfg = { ...cfg, ...(await chrome.storage.local.get(Object.keys(cfg))) }; };
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && Object.keys(ch).some(k => k in cfg)) load();
  });

  const words = () => String(cfg.acceptWords).toLowerCase().split(',').map(w => w.trim()).filter(Boolean);
  const visible = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== 'hidden'; };
  const matches = (t, w) => t === w || (t.startsWith(w) && /^[(\d]/.test(t.slice(w.length).trim()));

  function scan() {
    timer = null;
    const w = words();
    if (!w.length || cfg.soundId === 'off') { shown = false; return; }
    const found = [...document.querySelectorAll('button,[role="button"],a')].some(el => {
      const t = (el.textContent || '').trim().toLowerCase();
      return t.length > 0 && t.length <= 30 && w.some(x => matches(t, x)) && visible(el);
    });
    // первые 5 секунд после загрузки только запоминаем состояние (чтобы не звенеть на баннерах)
    if (found && !shown && performance.now() - t0 > 5000) FXS.play(cfg.soundId, cfg.soundVol / 100, cfg.soundCustom);
    shown = found;
  }
  const kick = () => { if (!timer) timer = setTimeout(scan, 250); };

  load().then(() => {
    new MutationObserver(kick).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    setInterval(kick, 2000);
  });
})();
