window.FXS = (() => {
  let ctx = null;
  const tone = (c, out, t, f, d, type = 'sine', g = 0.5) => {
    const o = c.createOscillator(), a = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    a.gain.setValueAtTime(0.0001, t);
    a.gain.exponentialRampToValueAtTime(g, t + 0.01);
    a.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(a); a.connect(out); o.start(t); o.stop(t + d + 0.05);
  };
  const P = {
    beep: (c, o, t) => { tone(c, o, t, 880, 0.18); tone(c, o, t + 0.25, 880, 0.18); },
    chime: (c, o, t) => [523, 659, 784].forEach((f, i) => tone(c, o, t + i * 0.15, f, 0.5)),
    ping: (c, o, t) => tone(c, o, t, 1400, 0.25, 'triangle'),
    bell: (c, o, t) => { tone(c, o, t, 1200, 1.2); tone(c, o, t, 2400, 0.8, 'sine', 0.2); },
    alarm: (c, o, t) => [0, 1, 2, 3].forEach(i => tone(c, o, t + i * 0.2, i % 2 ? 900 : 600, 0.18, 'square', 0.25)),
    horn: (c, o, t) => { tone(c, o, t, 220, 0.7, 'sawtooth', 0.3); tone(c, o, t, 277, 0.7, 'sawtooth', 0.2); }
  };
  const NAMES = { chime: 'Перезвон', beep: 'Сигнал', ping: 'Пинг', bell: 'Колокол', alarm: 'Тревога', horn: 'Гудок' };

  function play(id, vol = 0.7, custom = '') {
    if (id === 'off') return;
    if (id === 'custom') {
      if (!custom) return;
      const a = new Audio(custom); a.volume = Math.max(0, Math.min(1, vol)); a.play().catch(() => {});
      return;
    }
    ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
    const out = ctx.createGain(); out.gain.value = vol; out.connect(ctx.destination);
    (P[id] || P.chime)(ctx, out, ctx.currentTime + 0.02);
  }
  return { play, NAMES };
})();
