const API = 'https://open.faceit.com/data/v4';
const cache = new Map();

async function api(path, key, retried) {
  const r = await fetch(API + path, { headers: { Authorization: 'Bearer ' + key, Accept: 'application/json' } });
  if (r.status === 429 && !retried) { await new Promise(s => setTimeout(s, 1200)); return api(path, key, true); }
  if (!r.ok) {
    const msg = r.status === 401 || r.status === 403 ? 'API-ключ не принят (' + r.status + ')'
      : r.status === 429 ? 'Лимит запросов API, подожди минуту'
      : r.status === 404 ? 'Не найдено (404)' : 'Ошибка API ' + r.status;
    const e = new Error(msg); e.status = r.status; throw e;
  }
  return r.json();
}

async function load(nick, key) {
  let p;
  try { p = await api('/players?nickname=' + encodeURIComponent(nick), key); }
  catch (e) { throw e.status === 404 ? new Error('Игрок «' + nick + '» не найден') : e; }
  const id = p.player_id;
  const [stats, hist] = await Promise.all([
    api(`/players/${id}/stats/cs2`, key).catch(e => { throw e.status === 404 ? new Error('У игрока нет статистики CS2') : e; }),
    api(`/players/${id}/games/cs2/stats?limit=30`, key).catch(() => ({ items: [] }))
  ]);
  return { player: p, stats, matches: hist.items || [] };
}

async function pool(items, n, fn) {
  const q = items.map((x, i) => [x, i]);
  await Promise.all(Array.from({ length: n }, async () => { while (q.length) { const [x, i] = q.shift(); await fn(x, i); } }));
}

async function loadMeets(meId, key, ids, curId) {
  const res = {};
  for (let off = 0; off < 300; off += 100) {
    const r = await api(`/players/${meId}/history?game=cs2&from=1500000000&limit=100&offset=${off}`, key).catch(() => ({ items: [] }));
    const items = r.items || [];
    for (const h of items) {
      if (h.match_id === curId || (h.status && String(h.status).toLowerCase() !== 'finished')) continue;
      const f = Object.entries(h.teams || {});
      const mine = f.find(([, t]) => (t.players || []).some(p => p.player_id === meId));
      if (!mine) continue;
      const w = h.results && h.results.winner;
      for (const [k, t] of f) for (const p of t.players || []) {
        if (p.player_id === meId || !ids.has(p.player_id)) continue;
        (res[p.player_id] = res[p.player_id] || []).push({ t: h.finished_at, same: k === mine[0], win: w ? (w === mine[0] || w === mine[1].team_id) : null });
      }
    }
    if (items.length < 100) break;
  }
  return res;
}

async function loadRoom(id, key, me) {
  const m = await api('/matches/' + id, key).catch(e => { throw e.status === 404 ? new Error('Матч не найден (404)') : e; });
  const teams = Object.values(m.teams || {}).slice(0, 2);
  const all = teams.flatMap((t, i) => (t.roster || t.players || []).map(p => ({ p, team: i })));
  if (teams.length < 2 || !all.length) throw new Error('В ответе API нет составов команд');
  const map = (((m.voting || {}).map || {}).pick || [])[0] || null;
  const players = new Array(all.length);
  await pool(all, 5, async ({ p, team }, i) => {
    const pid = p.player_id, ck = 'p:' + pid, c = cache.get(ck);
    let d;
    if (c && Date.now() - c.t < 6e5) d = c.d;
    else {
      const [info, hist] = await Promise.all([
        api('/players/' + pid, key).catch(() => ({})),
        api(`/players/${pid}/games/cs2/stats?limit=30`, key).catch(() => ({ items: [] }))
      ]);
      const g = (info.games || {}).cs2 || {};
      d = { elo: g.faceit_elo ?? null, level: g.skill_level ?? p.game_skill_level ?? null, matches: hist.items || [] };
      cache.set(ck, { t: Date.now(), d });
    }
    players[i] = { id: pid, team, nick: p.nickname, ...d };
  });
  let meets = null, meId = null;
  if (me) {
    try {
      const mine = players.find(p => p && p.nick && p.nick.toLowerCase() === me.toLowerCase());
      meId = mine ? mine.id : (await api('/players?nickname=' + encodeURIComponent(me), key)).player_id;
      meets = await loadMeets(meId, key, new Set(players.map(p => p.id)), id);
    } catch { meets = null; }
  }
  return { map, teams: teams.map(t => ({ name: t.name, winProb: (t.stats || {}).winProbability ?? null, calcElo: m.calculate_elo })), players, meets, meId };
}

chrome.runtime.onMessage.addListener((m, _s, send) => {
  if (m.type === 'room') {
    (async () => {
      try {
        const c = cache.get('room:' + m.id + (m.me || ''));
        if (!m.force && c && Date.now() - c.t < 3e5) return send({ ok: true, data: c.d });
        const d = await loadRoom(m.id, m.key, m.me);
        cache.set('room:' + m.id + (m.me || ''), { t: Date.now(), d });
        send({ ok: true, data: d });
      } catch (e) { send({ ok: false, error: e.message }); }
    })();
    return true;
  }
  if (m.type === 'opts') { chrome.runtime.openOptionsPage(); return; }
  if (m.type === 'stats') {
    (async () => {
      try {
        const k = m.nick.toLowerCase(), c = cache.get(k);
        if (!m.force && c && Date.now() - c.t < 3e5) return send({ ok: true, data: c.d });
        const d = await load(m.nick, m.key);
        cache.set(k, { t: Date.now(), d });
        send({ ok: true, data: d });
      } catch (e) { send({ ok: false, error: e.message }); }
    })();
    return true;
  }
});

chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
